-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 02, 2023 at 09:51 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `quanlykho`
--

-- --------------------------------------------------------

--
-- Table structure for table `bienbankiemke`
--

CREATE TABLE `bienbankiemke` (
  `maBienBanKiemKe` int(11) NOT NULL auto_increment,
  `maKho` int(11) NOT NULL,
  `maLoHang` int(11) NOT NULL,
  `maTaiKhoan` varchar(10) NOT NULL,
  `ngayLap` date NOT NULL,
  `moTaKiemKe` varchar(100) NOT NULL,
  `soLuongKiemKe` double NOT NULL,
  PRIMARY KEY  (`maBienBanKiemKe`),
  KEY `maKho` (`maKho`,`maLoHang`,`maTaiKhoan`),
  KEY `maKho_2` (`maKho`),
  KEY `maLoHang` (`maLoHang`),
  KEY `maTaiKhoan` (`maTaiKhoan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bienbankiemke`
--


-- --------------------------------------------------------

--
-- Table structure for table `chitietxuatlo`
--

CREATE TABLE `chitietxuatlo` (
  `maChiTietXuatLo` int(11) NOT NULL auto_increment,
  `maLoHang` int(11) NOT NULL,
  `maPhieuXuatKho` int(11) NOT NULL,
  `soLuong` double NOT NULL,
  PRIMARY KEY  (`maChiTietXuatLo`),
  KEY `maLoHang` (`maLoHang`,`maPhieuXuatKho`),
  KEY `maPhieuXuatKho` (`maPhieuXuatKho`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `chitietxuatlo`
--


-- --------------------------------------------------------

--
-- Table structure for table `kho`
--

CREATE TABLE `kho` (
  `maKho` int(11) NOT NULL auto_increment,
  `tenKho` varchar(50) NOT NULL,
  `sucChua` double NOT NULL,
  `maNhanVien` varchar(10) NOT NULL,
  PRIMARY KEY  (`maKho`),
  KEY `maNhanVien` (`maNhanVien`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `kho`
--


-- --------------------------------------------------------

--
-- Table structure for table `lohang`
--

CREATE TABLE `lohang` (
  `maLoHang` int(11) NOT NULL,
  `soLuong` double NOT NULL,
  `donViTinh` varchar(10) NOT NULL,
  `ngaySanXuat` date NOT NULL,
  `hanSuDung` date NOT NULL,
  `maKho` int(11) NOT NULL,
  PRIMARY KEY  (`maLoHang`),
  KEY `maKho` (`maKho`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lohang`
--


-- --------------------------------------------------------

--
-- Table structure for table `nguyenvatlieu`
--

CREATE TABLE `nguyenvatlieu` (
  `maNguyenVatLieu` int(11) NOT NULL auto_increment,
  `tenNguyenVatLieu` varchar(50) NOT NULL,
  `soLuong` double NOT NULL,
  `donViTinh` varchar(10) NOT NULL,
  PRIMARY KEY  (`maNguyenVatLieu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `nguyenvatlieu`
--


-- --------------------------------------------------------

--
-- Table structure for table `nhanvien`
--

CREATE TABLE `nhanvien` (
  `tenNhanVien` varchar(100) NOT NULL,
  `maNhanVien` varchar(10) NOT NULL,
  PRIMARY KEY  (`maNhanVien`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nhanvien`
--


-- --------------------------------------------------------

--
-- Table structure for table `phieudieuphoi`
--

CREATE TABLE `phieudieuphoi` (
  `maPhieuDieuPhoi` int(11) NOT NULL auto_increment,
  `ngayLapPhieu` date NOT NULL,
  `ngayDuKienNX` date NOT NULL,
  `maKho` int(11) NOT NULL,
  `maViTri` int(11) NOT NULL,
  `maLoHang` int(11) NOT NULL,
  PRIMARY KEY  (`maPhieuDieuPhoi`),
  KEY `maKho` (`maKho`,`maViTri`,`maLoHang`),
  KEY `maViTri` (`maViTri`),
  KEY `maLoHang` (`maLoHang`),
  KEY `maKho_2` (`maKho`),
  KEY `maKho_3` (`maKho`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `phieudieuphoi`
--


-- --------------------------------------------------------

--
-- Table structure for table `phieunhapkho`
--

CREATE TABLE `phieunhapkho` (
  `maPhieuNhapKho` int(11) NOT NULL auto_increment,
  `maKho` int(11) NOT NULL,
  `maLoHang` int(11) NOT NULL,
  `ngayLapPhieu` date NOT NULL,
  PRIMARY KEY  (`maPhieuNhapKho`),
  KEY `maKho` (`maKho`,`maLoHang`),
  KEY `maKho_2` (`maKho`),
  KEY `maLoHang` (`maLoHang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `phieunhapkho`
--


-- --------------------------------------------------------

--
-- Table structure for table `phieuxuatkho`
--

CREATE TABLE `phieuxuatkho` (
  `maPhieuXuatKho` int(11) NOT NULL,
  `maChiTietXuatLo` int(11) NOT NULL,
  `maKho` int(11) NOT NULL,
  `ngayLapPhieu` date default NULL,
  PRIMARY KEY  (`maPhieuXuatKho`),
  KEY `maChiTietXuatLo` (`maChiTietXuatLo`,`maKho`),
  KEY `maChiTietXuatLo_2` (`maChiTietXuatLo`),
  KEY `maKho` (`maKho`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `phieuxuatkho`
--


-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `matKhau` int(11) NOT NULL,
  `maTaiKhoan` varchar(10) NOT NULL,
  PRIMARY KEY  (`maTaiKhoan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`matKhau`, `maTaiKhoan`) VALUES
(0, 'TK003');

-- --------------------------------------------------------

--
-- Table structure for table `thanhpham`
--

CREATE TABLE `thanhpham` (
  `maThanhPham` int(11) NOT NULL auto_increment,
  `tenThanhPham` varchar(50) NOT NULL,
  `soLuong` double NOT NULL,
  `donViTinh` varchar(5) NOT NULL,
  PRIMARY KEY  (`maThanhPham`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `thanhpham`
--


-- --------------------------------------------------------

--
-- Table structure for table `vitri`
--

CREATE TABLE `vitri` (
  `maViTri` int(11) NOT NULL auto_increment,
  `maKho` int(11) NOT NULL,
  `sucChua` double NOT NULL,
  PRIMARY KEY  (`maViTri`),
  KEY `maKho` (`maKho`),
  KEY `maKho_2` (`maKho`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `vitri`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `bienbankiemke`
--
ALTER TABLE `bienbankiemke`
  ADD CONSTRAINT `bienbankiemke_ibfk_10` FOREIGN KEY (`maTaiKhoan`) REFERENCES `taikhoan` (`maTaiKhoan`),
  ADD CONSTRAINT `bienbankiemke_ibfk_8` FOREIGN KEY (`maKho`) REFERENCES `kho` (`maKho`),
  ADD CONSTRAINT `bienbankiemke_ibfk_9` FOREIGN KEY (`maLoHang`) REFERENCES `lohang` (`maLoHang`);

--
-- Constraints for table `chitietxuatlo`
--
ALTER TABLE `chitietxuatlo`
  ADD CONSTRAINT `chitietxuatlo_ibfk_1` FOREIGN KEY (`maLoHang`) REFERENCES `lohang` (`maLoHang`),
  ADD CONSTRAINT `chitietxuatlo_ibfk_2` FOREIGN KEY (`maPhieuXuatKho`) REFERENCES `phieuxuatkho` (`maPhieuXuatKho`);

--
-- Constraints for table `kho`
--
ALTER TABLE `kho`
  ADD CONSTRAINT `kho_ibfk_1` FOREIGN KEY (`maNhanVien`) REFERENCES `nhanvien` (`maNhanVien`);

--
-- Constraints for table `lohang`
--
ALTER TABLE `lohang`
  ADD CONSTRAINT `lohang_ibfk_1` FOREIGN KEY (`maKho`) REFERENCES `kho` (`maKho`);

--
-- Constraints for table `nhanvien`
--
ALTER TABLE `nhanvien`
  ADD CONSTRAINT `nhanvien_ibfk_1` FOREIGN KEY (`maNhanVien`) REFERENCES `taikhoan` (`maTaiKhoan`);

--
-- Constraints for table `phieudieuphoi`
--
ALTER TABLE `phieudieuphoi`
  ADD CONSTRAINT `phieudieuphoi_ibfk_1` FOREIGN KEY (`maKho`) REFERENCES `kho` (`maKho`),
  ADD CONSTRAINT `phieudieuphoi_ibfk_2` FOREIGN KEY (`maViTri`) REFERENCES `vitri` (`maViTri`),
  ADD CONSTRAINT `phieudieuphoi_ibfk_3` FOREIGN KEY (`maLoHang`) REFERENCES `lohang` (`maLoHang`);

--
-- Constraints for table `phieunhapkho`
--
ALTER TABLE `phieunhapkho`
  ADD CONSTRAINT `phieunhapkho_ibfk_1` FOREIGN KEY (`maKho`) REFERENCES `kho` (`maKho`),
  ADD CONSTRAINT `phieunhapkho_ibfk_2` FOREIGN KEY (`maLoHang`) REFERENCES `lohang` (`maLoHang`);

--
-- Constraints for table `phieuxuatkho`
--
ALTER TABLE `phieuxuatkho`
  ADD CONSTRAINT `phieuxuatkho_ibfk_1` FOREIGN KEY (`maChiTietXuatLo`) REFERENCES `chitietxuatlo` (`maChiTietXuatLo`),
  ADD CONSTRAINT `phieuxuatkho_ibfk_2` FOREIGN KEY (`maKho`) REFERENCES `kho` (`maKho`);

--
-- Constraints for table `vitri`
--
ALTER TABLE `vitri`
  ADD CONSTRAINT `vitri_ibfk_1` FOREIGN KEY (`maKho`) REFERENCES `kho` (`maKho`);
